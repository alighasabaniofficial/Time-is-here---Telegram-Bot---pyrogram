# Your api_key & api_hash & bot_token

api_id = 0
api_hash = ''
bot_token = ''
